import { forwardRef, useId } from "react";
import { cn } from "@/lib/utils";

/* ==========================================================================
   INPUT COMPONENT - WCAG 2.1 AA Compliant
   
   Accessibilità implementata:
   - 1.3.1 Info and Relationships: label associata programmaticamente
   - 1.3.5 Identify Input Purpose: autocomplete supportato
   - 3.3.1 Error Identification: aria-invalid e aria-describedby
   - 3.3.2 Labels or Instructions: label e hint text
   - 4.1.2 Name, Role, Value: aria-label e aria-labelledby
   ========================================================================== */

export interface InputProps
  extends React.InputHTMLAttributes<HTMLInputElement> {
  /** Label visibile sopra l'input */
  label?: string;
  /** Testo di aiuto sotto l'input */
  hint?: string;
  /** Messaggio di errore */
  error?: string;
  /** Icona a sinistra */
  leftIcon?: React.ReactNode;
  /** Icona/elemento a destra */
  rightIcon?: React.ReactNode;
  /** Rende il campo obbligatorio visivamente */
  required?: boolean;
}

export const Input = forwardRef<HTMLInputElement, InputProps>(
  (
    {
      label,
      hint,
      error,
      leftIcon,
      rightIcon,
      required,
      className,
      id,
      "aria-describedby": ariaDescribedBy,
      ...props
    },
    ref
  ) => {
    // Genera ID unici per accessibilità
    const generatedId = useId();
    const inputId = id || generatedId;
    const hintId = `${inputId}-hint`;
    const errorId = `${inputId}-error`;

    // Costruisci aria-describedby dinamicamente
    const describedByIds: string[] = [];
    if (ariaDescribedBy) describedByIds.push(ariaDescribedBy);
    if (hint) describedByIds.push(hintId);
    if (error) describedByIds.push(errorId);

    const hasError = Boolean(error);

    return (
      <div className="w-full">
        {/* Label */}
        {label && (
          <label
            htmlFor={inputId}
            className="label mb-1.5 flex items-center gap-1"
            data-required={required}
          >
            {label}
            {required && (
              <span className="text-red-600" aria-hidden="true">
                *
              </span>
            )}
            {required && <span className="sr-only">(obbligatorio)</span>}
          </label>
        )}

        {/* Input wrapper */}
        <div className="relative">
          {/* Left icon */}
          {leftIcon && (
            <div
              className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none"
              aria-hidden="true"
            >
              {leftIcon}
            </div>
          )}

          {/* Input */}
          <input
            ref={ref}
            id={inputId}
            className={cn(
              "input w-full",
              leftIcon && "pl-10",
              rightIcon && "pr-10",
              hasError && "border-red-500 focus:border-red-500 focus:ring-red-500/20",
              className
            )}
            aria-invalid={hasError}
            aria-describedby={
              describedByIds.length > 0 ? describedByIds.join(" ") : undefined
            }
            aria-required={required}
            {...props}
          />

          {/* Right icon */}
          {rightIcon && (
            <div className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400">
              {rightIcon}
            </div>
          )}
        </div>

        {/* Hint text */}
        {hint && !error && (
          <p id={hintId} className="mt-1.5 text-sm text-gray-500">
            {hint}
          </p>
        )}

        {/* Error message */}
        {error && (
          <p
            id={errorId}
            className="mt-1.5 text-sm text-red-600 flex items-center gap-1"
            role="alert"
            aria-live="polite"
          >
            <svg
              className="h-4 w-4 flex-shrink-0"
              fill="currentColor"
              viewBox="0 0 20 20"
              aria-hidden="true"
            >
              <path
                fillRule="evenodd"
                d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z"
                clipRule="evenodd"
              />
            </svg>
            {error}
          </p>
        )}
      </div>
    );
  }
);

Input.displayName = "Input";

/* ==========================================================================
   TEXTAREA COMPONENT
   ========================================================================== */

export interface TextareaProps
  extends React.TextareaHTMLAttributes<HTMLTextAreaElement> {
  label?: string;
  hint?: string;
  error?: string;
  required?: boolean;
}

export const Textarea = forwardRef<HTMLTextAreaElement, TextareaProps>(
  (
    {
      label,
      hint,
      error,
      required,
      className,
      id,
      "aria-describedby": ariaDescribedBy,
      ...props
    },
    ref
  ) => {
    const generatedId = useId();
    const textareaId = id || generatedId;
    const hintId = `${textareaId}-hint`;
    const errorId = `${textareaId}-error`;

    const describedByIds: string[] = [];
    if (ariaDescribedBy) describedByIds.push(ariaDescribedBy);
    if (hint) describedByIds.push(hintId);
    if (error) describedByIds.push(errorId);

    const hasError = Boolean(error);

    return (
      <div className="w-full">
        {label && (
          <label
            htmlFor={textareaId}
            className="label mb-1.5 flex items-center gap-1"
            data-required={required}
          >
            {label}
            {required && (
              <span className="text-red-600" aria-hidden="true">
                *
              </span>
            )}
            {required && <span className="sr-only">(obbligatorio)</span>}
          </label>
        )}

        <textarea
          ref={ref}
          id={textareaId}
          className={cn(
            "input w-full min-h-[100px] resize-y",
            hasError && "border-red-500 focus:border-red-500 focus:ring-red-500/20",
            className
          )}
          aria-invalid={hasError}
          aria-describedby={
            describedByIds.length > 0 ? describedByIds.join(" ") : undefined
          }
          aria-required={required}
          {...props}
        />

        {hint && !error && (
          <p id={hintId} className="mt-1.5 text-sm text-gray-500">
            {hint}
          </p>
        )}

        {error && (
          <p
            id={errorId}
            className="mt-1.5 text-sm text-red-600 flex items-center gap-1"
            role="alert"
            aria-live="polite"
          >
            <svg
              className="h-4 w-4 flex-shrink-0"
              fill="currentColor"
              viewBox="0 0 20 20"
              aria-hidden="true"
            >
              <path
                fillRule="evenodd"
                d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z"
                clipRule="evenodd"
              />
            </svg>
            {error}
          </p>
        )}
      </div>
    );
  }
);

Textarea.displayName = "Textarea";

/* ==========================================================================
   SELECT COMPONENT
   ========================================================================== */

export interface SelectProps
  extends React.SelectHTMLAttributes<HTMLSelectElement> {
  label?: string;
  hint?: string;
  error?: string;
  required?: boolean;
  options: Array<{ value: string; label: string; disabled?: boolean }>;
}

export const Select = forwardRef<HTMLSelectElement, SelectProps>(
  (
    {
      label,
      hint,
      error,
      required,
      options,
      className,
      id,
      "aria-describedby": ariaDescribedBy,
      ...props
    },
    ref
  ) => {
    const generatedId = useId();
    const selectId = id || generatedId;
    const hintId = `${selectId}-hint`;
    const errorId = `${selectId}-error`;

    const describedByIds: string[] = [];
    if (ariaDescribedBy) describedByIds.push(ariaDescribedBy);
    if (hint) describedByIds.push(hintId);
    if (error) describedByIds.push(errorId);

    const hasError = Boolean(error);

    return (
      <div className="w-full">
        {label && (
          <label
            htmlFor={selectId}
            className="label mb-1.5 flex items-center gap-1"
            data-required={required}
          >
            {label}
            {required && (
              <span className="text-red-600" aria-hidden="true">
                *
              </span>
            )}
            {required && <span className="sr-only">(obbligatorio)</span>}
          </label>
        )}

        <div className="relative">
          <select
            ref={ref}
            id={selectId}
            className={cn(
              "input w-full appearance-none pr-10 cursor-pointer",
              hasError && "border-red-500 focus:border-red-500 focus:ring-red-500/20",
              className
            )}
            aria-invalid={hasError}
            aria-describedby={
              describedByIds.length > 0 ? describedByIds.join(" ") : undefined
            }
            aria-required={required}
            {...props}
          >
            {options.map((option) => (
              <option
                key={option.value}
                value={option.value}
                disabled={option.disabled}
              >
                {option.label}
              </option>
            ))}
          </select>

          {/* Dropdown arrow */}
          <div
            className="absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none text-gray-400"
            aria-hidden="true"
          >
            <svg
              className="h-5 w-5"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M19 9l-7 7-7-7"
              />
            </svg>
          </div>
        </div>

        {hint && !error && (
          <p id={hintId} className="mt-1.5 text-sm text-gray-500">
            {hint}
          </p>
        )}

        {error && (
          <p
            id={errorId}
            className="mt-1.5 text-sm text-red-600 flex items-center gap-1"
            role="alert"
            aria-live="polite"
          >
            <svg
              className="h-4 w-4 flex-shrink-0"
              fill="currentColor"
              viewBox="0 0 20 20"
              aria-hidden="true"
            >
              <path
                fillRule="evenodd"
                d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z"
                clipRule="evenodd"
              />
            </svg>
            {error}
          </p>
        )}
      </div>
    );
  }
);

Select.displayName = "Select";

/* ==========================================================================
   CHECKBOX COMPONENT
   ========================================================================== */

export interface CheckboxProps
  extends Omit<React.InputHTMLAttributes<HTMLInputElement>, "type"> {
  label: React.ReactNode;
  hint?: string;
  error?: string;
}

export const Checkbox = forwardRef<HTMLInputElement, CheckboxProps>(
  ({ label, hint, error, className, id, ...props }, ref) => {
    const generatedId = useId();
    const checkboxId = id || generatedId;
    const hintId = `${checkboxId}-hint`;
    const errorId = `${checkboxId}-error`;

    const describedByIds: string[] = [];
    if (hint) describedByIds.push(hintId);
    if (error) describedByIds.push(errorId);

    const hasError = Boolean(error);

    return (
      <div className="w-full">
        <label className="flex items-start gap-3 cursor-pointer">
          <input
            ref={ref}
            type="checkbox"
            id={checkboxId}
            className={cn(
              "mt-0.5 h-5 w-5 rounded border-gray-300",
              "text-primary-600 focus:ring-primary-500 focus:ring-2 focus:ring-offset-2",
              hasError && "border-red-500",
              className
            )}
            aria-invalid={hasError}
            aria-describedby={
              describedByIds.length > 0 ? describedByIds.join(" ") : undefined
            }
            {...props}
          />
          <span className="text-sm text-gray-700">{label}</span>
        </label>

        {hint && !error && (
          <p id={hintId} className="mt-1.5 ml-8 text-sm text-gray-500">
            {hint}
          </p>
        )}

        {error && (
          <p
            id={errorId}
            className="mt-1.5 ml-8 text-sm text-red-600"
            role="alert"
            aria-live="polite"
          >
            {error}
          </p>
        )}
      </div>
    );
  }
);

Checkbox.displayName = "Checkbox";
