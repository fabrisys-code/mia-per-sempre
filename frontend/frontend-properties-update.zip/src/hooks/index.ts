export { useProperties, useProperty } from "./useProperties";
