"use client";

import { useState, useCallback, useEffect } from "react";
import api, { ApiError } from "@/lib/api";
import type { Property, PropertyFilters, SearchParams } from "@/types";

interface UsePropertiesOptions {
  initialFilters?: PropertyFilters;
  pageSize?: number;
  autoFetch?: boolean;
}

interface UsePropertiesReturn {
  // Data
  properties: Property[];
  totalResults: number;
  totalPages: number;
  currentPage: number;

  // Filters
  filters: PropertyFilters;
  setFilters: (filters: PropertyFilters) => void;
  updateFilter: <K extends keyof PropertyFilters>(
    key: K,
    value: PropertyFilters[K]
  ) => void;
  resetFilters: () => void;

  // Sorting
  sortBy: string;
  setSortBy: (sort: string) => void;

  // Pagination
  setPage: (page: number) => void;

  // State
  isLoading: boolean;
  error: string | null;

  // Actions
  fetchProperties: () => Promise<void>;
  refresh: () => Promise<void>;
}

const defaultFilters: PropertyFilters = {};

export function useProperties({
  initialFilters = defaultFilters,
  pageSize = 12,
  autoFetch = true,
}: UsePropertiesOptions = {}): UsePropertiesReturn {
  // State
  const [properties, setProperties] = useState<Property[]>([]);
  const [totalResults, setTotalResults] = useState(0);
  const [currentPage, setCurrentPage] = useState(1);
  const [filters, setFilters] = useState<PropertyFilters>(initialFilters);
  const [sortBy, setSortBy] = useState("date_desc");
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Calculate total pages
  const totalPages = Math.ceil(totalResults / pageSize);

  // Parse sort string to API params
  const parseSortBy = (sort: string): { sort_by: string; sort_order: "asc" | "desc" } => {
    const [field, order] = sort.split("_");
    return {
      sort_by: field === "date" ? "created_at" : field,
      sort_order: order as "asc" | "desc",
    };
  };

  // Fetch properties
  const fetchProperties = useCallback(async () => {
    setIsLoading(true);
    setError(null);

    try {
      const { sort_by, sort_order } = parseSortBy(sortBy);

      const params: SearchParams = {
        ...filters,
        page: currentPage,
        page_size: pageSize,
        sort_by: sort_by as "price" | "date" | "surface",
        sort_order,
      };

      // Remove empty values
      const cleanParams = Object.fromEntries(
        Object.entries(params).filter(
          ([, v]) => v !== undefined && v !== "" && v !== null
        )
      ) as SearchParams;

      const response = await api.properties.search(cleanParams);

      setProperties(response.items || []);
      setTotalResults(response.total || 0);
    } catch (err) {
      console.error("Error fetching properties:", err);
      if (err instanceof ApiError) {
        setError(err.message);
      } else {
        setError("Errore nel caricamento degli immobili");
      }
      setProperties([]);
      setTotalResults(0);
    } finally {
      setIsLoading(false);
    }
  }, [filters, currentPage, pageSize, sortBy]);

  // Update single filter
  const updateFilter = useCallback(
    <K extends keyof PropertyFilters>(key: K, value: PropertyFilters[K]) => {
      setFilters((prev) => ({ ...prev, [key]: value }));
    },
    []
  );

  // Reset filters
  const resetFilters = useCallback(() => {
    setFilters(defaultFilters);
    setCurrentPage(1);
  }, []);

  // Set page
  const setPage = useCallback((page: number) => {
    setCurrentPage(page);
    // Scroll to top
    window.scrollTo({ top: 0, behavior: "smooth" });
  }, []);

  // Handle sort change
  const handleSortChange = useCallback((sort: string) => {
    setSortBy(sort);
    setCurrentPage(1); // Reset to first page
  }, []);

  // Handle filters change
  const handleFiltersChange = useCallback((newFilters: PropertyFilters) => {
    setFilters(newFilters);
    setCurrentPage(1); // Reset to first page
  }, []);

  // Refresh
  const refresh = useCallback(async () => {
    await fetchProperties();
  }, [fetchProperties]);

  // Auto-fetch on mount and when dependencies change
  useEffect(() => {
    if (autoFetch) {
      fetchProperties();
    }
  }, [autoFetch, fetchProperties]);

  return {
    // Data
    properties,
    totalResults,
    totalPages,
    currentPage,

    // Filters
    filters,
    setFilters: handleFiltersChange,
    updateFilter,
    resetFilters,

    // Sorting
    sortBy,
    setSortBy: handleSortChange,

    // Pagination
    setPage,

    // State
    isLoading,
    error,

    // Actions
    fetchProperties,
    refresh,
  };
}

// Hook per singola property
export function useProperty(id: number | null) {
  const [property, setProperty] = useState<Property | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchProperty = useCallback(async () => {
    if (!id) return;

    setIsLoading(true);
    setError(null);

    try {
      const data = await api.properties.get(id);
      setProperty(data);
    } catch (err) {
      console.error("Error fetching property:", err);
      if (err instanceof ApiError) {
        if (err.isNotFound()) {
          setError("Immobile non trovato");
        } else {
          setError(err.message);
        }
      } else {
        setError("Errore nel caricamento dell'immobile");
      }
      setProperty(null);
    } finally {
      setIsLoading(false);
    }
  }, [id]);

  useEffect(() => {
    if (id) {
      fetchProperty();
    }
  }, [id, fetchProperty]);

  return {
    property,
    isLoading,
    error,
    refresh: fetchProperty,
  };
}
